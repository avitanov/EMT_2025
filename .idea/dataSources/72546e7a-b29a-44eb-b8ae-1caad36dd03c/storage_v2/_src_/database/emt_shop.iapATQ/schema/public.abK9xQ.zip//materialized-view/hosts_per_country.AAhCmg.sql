create materialized view hosts_per_country as
SELECT c.id        AS country_id,
       count(h.id) AS num_hosts
FROM country c
         LEFT JOIN host h ON h.country_id = c.id
GROUP BY c.id;

alter materialized view hosts_per_country owner to emt;


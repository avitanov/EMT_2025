create materialized view accommodations_per_host as
SELECT h.id        AS host_id,
       count(a.id) AS num_accommodations
FROM host h
         LEFT JOIN accommodation a ON a.host_id = h.id
GROUP BY h.id;

alter materialized view accommodations_per_host owner to emt;

